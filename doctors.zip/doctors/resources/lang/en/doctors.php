<?php

return [
    'name' => 'Doctors',
    'create' => 'New doctors',
];
