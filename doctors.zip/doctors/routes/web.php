<?php

use Botble\Base\Facades\AdminHelper;
use Botble\Doctors\Http\Controllers\DoctorsController;
use Illuminate\Support\Facades\Route;
use Botble\Doctors\Http\Controllers\CategoryController;
AdminHelper::registerRoutes(function () {
    Route::group(['prefix' => 'doctors', 'as' => 'doctors.'], function () {
        Route::resource('', DoctorsController::class)->parameters(['' => 'doctors']);

         Route::group(['prefix' => 'category', 'as' => 'category.'], function () {
                Route::resource('', CategoryController::class)->parameters(['' => 'category']);
            });
    });
    
           
});
