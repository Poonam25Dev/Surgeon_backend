<?php

use Illuminate\Support\Facades\Route;

Route::group([
    'middleware' => 'api',
    'prefix' => 'api/v1',
    'namespace' => 'Botble\CmsPluginsPlans\Http\Controllers\API'

], function () {
    Route::get('/categories', 'CategoryController@index');
    Route::get('/doctors', 'CategoryController@getDoctors');
});

