<?php

namespace Botble\Doctors\Models;

use Botble\Base\Casts\SafeContent;
use Botble\Base\Enums\BaseStatusEnum;
use Botble\Base\Models\BaseModel;

class DoctorCategory extends BaseModel
{
    protected $table = 'doctor_categories';

    protected $fillable = [
                            'title',	
                            'description',	
                            'image',	
                            'banner_img',	
                            'is_featured',	
                            'status',	    
                        ];

    protected $casts = [
        'status' => BaseStatusEnum::class,
        'name' => SafeContent::class,
    ];
}
