<?php

namespace Botble\Doctors\Models;

use Botble\Base\Casts\SafeContent;
use Botble\Base\Enums\BaseStatusEnum;
use Botble\Base\Models\BaseModel;

class Doctors extends BaseModel
{
    protected $table = 'doctors';

    protected $fillable = [
        'name',
        'founder',
        'description',
        'specialty_title',
        'conditions_treated',
        'treatments_procedures',
        'hospital_affiliations',
        'educational_background',
        'email',
        'contact_number',
        'clinic_name',
        'address',
        'office_hours',
        'professional_memberships',
        'years_of_experience',
        'languages_spoken',
        'publications_research',
        'is_featured',
        'is_claimed',
        'doctor_photo',
        'status',
    ];

    protected $casts = [
        'status' => BaseStatusEnum::class,
        'name' => SafeContent::class,
    ];
}
