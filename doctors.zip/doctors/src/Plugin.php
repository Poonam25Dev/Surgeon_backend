<?php

namespace Botble\Doctors;

use Illuminate\Support\Facades\Schema;
use Botble\PluginManagement\Abstracts\PluginOperationAbstract;

class Plugin extends PluginOperationAbstract
{
    public static function remove(): void
    {
        Schema::dropIfExists('Doctors');
        Schema::dropIfExists('Doctors_translations');
    }
}
