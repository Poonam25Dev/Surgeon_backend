<?php

namespace Botble\Doctors\Forms;

use Botble\Base\Facades\Assets;
use Botble\Base\Forms\FieldOptions\NameFieldOption;
use Botble\Base\Forms\FieldOptions\NumberFieldOption;
use Botble\Base\Forms\FieldOptions\OnOffFieldOption;
use Botble\Base\Forms\FieldOptions\SelectFieldOption;
use Botble\Base\Forms\FieldOptions\StatusFieldOption;
use Botble\Base\Forms\FieldOptions\TextFieldOption;
use Botble\Base\Forms\Fields\NumberField;
use Botble\Base\Forms\Fields\OnOffField;
use Botble\Base\Forms\Fields\TextField;
use Botble\Base\Forms\FormAbstract;
use Botble\Doctors\Http\Requests\CategoryRequest;
use Botble\Doctors\Models\DoctorCategory;
use Botble\Base\Forms\Fields\SelectField;
use Botble\Language\Facades\Language;
use Botble\Base\Forms\Fields\EditorField;
use Botble\Base\Forms\FieldOptions\EditorFieldOption;

class CategoryForm extends FormAbstract
{
     public function setup(): void
    {
       	
        $this
            ->model(DoctorCategory::class)
            ->setValidatorClass(CategoryRequest::class)
            ->add('title', TextField::class, NameFieldOption::make()->required()->label('Specialty Title'))
            ->add('description',  EditorField::class, EditorFieldOption::make()
                    ->allowedShortcodes() // If you want to allow UI Block (shortcodes) button in that editor
                    ->maxLength(10000) // Default is 10000, you can change it if you wish
                    ->rows(4) // Default is 4, you can change it if you wish
            )
            ->add(
                'is_featured',
                OnOffField::class,
                OnOffFieldOption::make()
                    ->label(__('Featured'))
                    ->defaultValue(false)
            )
           
           ->add('image', 'mediaImage', [
                    'label' => 'Image',
                ])
            ->add('banner_img', 'mediaImage', [
                    'label' => 'Banner Image',
                ])
            ->add('status', SelectField::class, StatusFieldOption::make())
            ->setBreakFieldPoint('status');
    }
}
