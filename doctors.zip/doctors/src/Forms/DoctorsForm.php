<?php

namespace Botble\Doctors\Forms;

use Botble\Base\Forms\FieldOptions\NameFieldOption;
use Botble\Base\Forms\FieldOptions\StatusFieldOption;
use Botble\Base\Forms\Fields\SelectField;
use Botble\Base\Forms\Fields\TextField;
use Botble\Base\Forms\FormAbstract;
use Botble\Doctor\Forms\CustomFieldForm;
use Botble\Doctors\Models\Doctors as Doctor;
use Botble\Base\Forms\Fields\NumberField;
use Botble\Doctors\Models\DoctorCategory as Category;
use Botble\Base\Forms\FieldOptions\NumberFieldOption;
use Botble\Base\Forms\Fields\MediaImageField;
use Botble\Base\Forms\FieldOptions\MediaImageFieldOption;
use Botble\Base\Forms\FieldOptions\TextFieldOption;
use Botble\Base\Forms\FieldOptions\SelectFieldOption;
use Botble\Base\Forms\Fields\OnOffField;
use Botble\Base\Forms\FieldOptions\OnOffFieldOption;
use Botble\Base\Forms\Fields\TinyMceField;
use Botble\Base\Forms\Fields\CkEditorField;
use Botble\Base\Forms\FieldOptions\EditorFieldOption;
use Botble\Base\Forms\FieldOptions\DescriptionFieldOption;
use Botble\Base\Forms\Fields\TextareaField;
use Botble\Doctors\Http\Requests\DoctorsRequest;

class DoctorsForm extends FormAbstract
{
    public function setup(): void
    {
        $this
            ->model(Doctor::class)
            ->setValidatorClass(DoctorsRequest::class)
            ->add('name', TextField::class, NameFieldOption::make()->required()->label('Doctor Name & Credentials'))
            ->add('description', TextareaField::class, DescriptionFieldOption::make()->label('Introduction')->placeholder('')->maxLength(10000))
            ->add('founder', TextField::class, TextFieldOption::make()->required()->label('Founder of'))
          
            ->add(
                'category_select_id', // not 'id'
                SelectField::class,
                SelectFieldOption::make()
                    ->label(__('Specialty'))
                    ->choices(Category::pluck('title', 'id')->toArray())
                    ->selected($this->model ? Category::where('title', $this->model->specialty_title)->value('id') : null)
                    ->required()
                    ->emptyValue(__('Please select specialty'))
                    ->searchable()
                    ->allowClear()
            )
           ->add(
                'conditions_treated', 
                CkEditorField::class, 
                EditorFieldOption::make()
                ->required()
                ->rows(3) // Default is 4, you can change it if you wish
            )
            ->add('treatments_procedures', TextareaField::class, DescriptionFieldOption::make()->required()->label('Treatments & Procedures')->placeholder('')->maxLength(10000))
            ->add('email', TextField::class, TextFieldOption::make()->required()->label('Email'))
            ->add('contact_number', TextField::class, TextFieldOption::make()->required()->label('Contact Number'))
            ->add('clinic_name',TextField::class, TextFieldOption::make()->required()->label('Practice Locations')->placeholder('Hospital or clinic name'))
            ->add('address', TextField::class, TextFieldOption::make()->required()->placeholder('Address')->labelAttributes(['style' => 'display:none']))
            ->add('office_hours',TextField::class, TextFieldOption::make()->required()->placeholder('Office hours')->labelAttributes(['style' => 'display:none']))
            ->add('hospital_affiliations', TextField::class, TextFieldOption::make()->required()->label('Hospital Affiliations'))
            ->add(
                'educational_background', 
                CkEditorField::class, 
                EditorFieldOption::make()
                ->required()
                ->rows(3) // Default is 4, you can change it if you wish
            )
            ->add('professional_memberships', TextField::class, TextFieldOption::make()->required()->label('Professional Memberships'))
            ->add('years_of_experience', NumberField::class, NumberFieldOption::make()->required()->label('Years of Experience'))
            ->add('languages_spoken', TextField::class, TextFieldOption::make()->label('Languages Spoken'))
            ->add('publications_research', TextareaField::class, DescriptionFieldOption::make()->label('Publications / Research')->placeholder('')->maxLength(10000))
            ->add('status', SelectField::class, StatusFieldOption::make())
            ->add(
                'is_featured',
                OnOffField::class,
                OnOffFieldOption::make()
                    ->label(__('Featured'))
                    ->defaultValue(false)
            )
            ->add(
                'is_claimed', 
                 SelectField::class, 
                 SelectFieldOption::make()
                    ->label(__('Claim Approved'))
                    ->choices([
                        '1' => __('Yes'),
                        '0' => __('No'),
                    ])
                    ->selected($this->model ? $this->model->is_claimed : '0')
                    ->disabled()
            )
            ->add(
                'doctor_photo', 
                MediaImageField::class, 
                MediaImageFieldOption::make()
                    ->label(__('Doctor Photo'))
            )
            ->setBreakFieldPoint('status');
    }
}
