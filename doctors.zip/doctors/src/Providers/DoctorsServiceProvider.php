<?php

namespace Botble\Doctors\Providers;

use Botble\Base\Supports\ServiceProvider;
use Botble\Base\Traits\LoadAndPublishDataTrait;
use Botble\Base\Facades\DashboardMenu;
use Botble\Doctors\Models\Doctors;
use Botble\Slug\Facades\SlugHelper;

class DoctorsServiceProvider extends ServiceProvider
{
    use LoadAndPublishDataTrait;

    public function boot(): void
    {
        $this
            ->setNamespace('plugins/doctors')
            ->loadHelpers()
            ->loadAndPublishConfigurations(['permissions'])
            ->loadAndPublishTranslations()
            ->loadRoutes()
            ->loadAndPublishViews()
            ->loadMigrations();
            
            if (defined('LANGUAGE_ADVANCED_MODULE_SCREEN_NAME')) {
                \Botble\LanguageAdvanced\Supports\LanguageAdvancedManager::registerModule(Doctors::class, [
                    'name',
                ]);
            }
            
            SlugHelper::registerModule(Doctors::class);
            
            DashboardMenu::default()->beforeRetrieving(function () {
                DashboardMenu::registerItem([
                    'id' => 'cms-plugins-doctors',
                    'priority' => 5,
                    'parent_id' => null,
                    'name' => 'plugins/doctors::doctors.name',
                    'icon' => 'ti ti-user',
                    'permissions' => ['doctors.index'],
                ]);
                
                 DashboardMenu::registerItem([
                    'id' => 'cms-plugins-new-doctors',
                    'priority' => 0,
                    'parent_id' => 'cms-plugins-doctors',
                    'name' => 'Manage Doctors',
                    'icon' => 'ti ti-box',
                    'url' => route('doctors.index'),
                    'permissions' => ['doctors.index'],
                ]);
                    DashboardMenu::registerItem([
                    'id' => 'cms-plugins-category',
                    'parent_id' => 'cms-plugins-doctors',
                    'priority' => 130,
                    'name' => 'Doctor Category',
                    'route' => 'doctors.category.index',
                    'permissions' => 'doctors.index',
                ]);
                
            });
    }
}
