<?php

namespace Botble\Doctors\Tables;

use Botble\Doctors\Models\Doctors;
use Botble\Table\Abstracts\TableAbstract;
use Botble\Table\Columns\Column;
use Botble\Table\Actions\DeleteAction;
use Botble\Table\Actions\EditAction;
use Botble\Table\BulkActions\DeleteBulkAction;
use Botble\Table\BulkChanges\CreatedAtBulkChange;
use Botble\Table\BulkChanges\NameBulkChange;
use Botble\Table\BulkChanges\StatusBulkChange;
use Botble\Table\Columns\CreatedAtColumn;
use Botble\Table\Columns\IdColumn;
use Botble\Table\Columns\NameColumn;
use Botble\Table\Columns\StatusColumn;
use Botble\Table\HeaderActions\CreateHeaderAction;
use Illuminate\Database\Eloquent\Builder;
use Botble\Table\Columns\ImageColumn;
use Illuminate\Support\Facades\Auth;
use Botble\Base\Models\User;

class DoctorsTable extends TableAbstract
{
    public function setup(): void
    {
        $this
            ->model(Doctors::class)
            ->addHeaderAction(CreateHeaderAction::make()->route('doctors.create'))
            ->addActions([
                EditAction::make()->route('doctors.edit'),
                DeleteAction::make()->route('doctors.destroy'),
            ])
            ->addColumns([
                IdColumn::make(),
                ImageColumn::make('doctor_photo')
                    ->title('Image')
                    ->width(70),
                NameColumn::make()->route('doctors.edit'),
                Column::make('specialty_title')->title('Specialt'),
                Column::make('contact_number')->title('Phone'),
                Column::make('years_of_experience')->title('Years of experience'),
                // CreatedAtColumn::make(),
                // StatusColumn::make(),
            ])
            ->addBulkActions([
                DeleteBulkAction::make()->permission('doctors.destroy'),
            ])
            ->addBulkChanges([
                NameBulkChange::make(),
                StatusBulkChange::make(),
                CreatedAtBulkChange::make(),
            ])
            ->queryUsing(function (Builder $query) {
                $query->select([
                    'id',
                    'doctor_photo',
                    'name',
                    'specialty_title',
                    'contact_number',
                    'years_of_experience',
                    // 'created_at',
                    // 'status',
                ]);
                
                if (! Auth::user()->isSuperUser()) {
                    $query->where('user_id', Auth::id());
                }

                return $query;
                
            });
    }
}
