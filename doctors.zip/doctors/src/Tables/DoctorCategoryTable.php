<?php

namespace Botble\Doctors\Tables;
use Botble\Doctors\Models\DoctorCategory;
use Botble\Table\Abstracts\TableAbstract;
use Botble\Table\Actions\DeleteAction;
use Botble\Table\Actions\EditAction;
use Botble\Table\BulkActions\DeleteBulkAction;
use Botble\Table\BulkChanges\CreatedAtBulkChange;
use Botble\Table\BulkChanges\NameBulkChange;
use Botble\Table\Columns\ImageColumn;
use Botble\Table\Columns\StatusColumn;
use Botble\Table\Columns\CreatedAtColumn;
use Botble\Table\Columns\EnumColumn;
use Botble\Table\Columns\IdColumn;
use Botble\Table\Columns\Column;
use Botble\Table\HeaderActions\CreateHeaderAction;
use Illuminate\Database\Eloquent\Builder;

class DoctorCategoryTable extends TableAbstract
{
    public function setup(): void
    {
        $this
            ->model(DoctorCategory::class)
            ->addHeaderAction(CreateHeaderAction::make()->route('doctors.category.create')->permission('contacts.edit'))
            ->addBulkChanges([
                CreatedAtBulkChange::make(),
            ])
            ->addBulkAction(DeleteBulkAction::make()->permission('doctors.edit'))
            ->addActions([
                EditAction::make()->route('doctors.category.edit')->permission('doctors.edit'),
                DeleteAction::make()->route('doctors.category.destroy')->permission('doctors.edit'),
            ])
            ->addColumns([
                IdColumn::make(),
                Column::make('title')->title('Speciality'),
                Column::make('description')->title('Description'),
                ImageColumn::make('image')
                    ->title('Image')
                    ->width(70),
                ImageColumn::make('banner_img')
                    ->title('Banner Image')
                    ->width(70),
                CreatedAtColumn::make(),
                StatusColumn::make(),
            ])
            ->queryUsing(fn (Builder $query) => $query->select([
                'id',
                'title',	
                'description',	
                'image',	
                'banner_img',	
                'is_featured',	
                'status',	   
                'created_at',
            ]));
    }
}
