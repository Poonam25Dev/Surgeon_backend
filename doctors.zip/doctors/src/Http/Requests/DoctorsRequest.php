<?php

namespace Botble\Doctors\Http\Requests;

use Botble\Base\Enums\BaseStatusEnum;
use Botble\Support\Http\Requests\Request;
use Illuminate\Validation\Rule;

class DoctorsRequest extends Request
{
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:220'],
            'category_select_id' => ['required'],
            // 'email' => 'required|email|unique:users,email',
            'contact_number' => ['required', 'string', 'max:20'],
            'clinic_name' => ['required', 'string', 'max:500'],
            'address' => ['required', 'string', 'max:1000'],
            'years_of_experience' => ['required', 'numeric', 'min:0', 'max:60'],
            'status' => Rule::in(BaseStatusEnum::values()),
        ];
    }
}
