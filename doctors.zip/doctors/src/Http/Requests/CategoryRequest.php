<?php

namespace Botble\Doctors\Http\Requests;

use Botble\Base\Rules\OnOffRule;
use Botble\Base\Enums\BaseStatusEnum;
use Botble\Doctors\Models\DoctorCategoryRequest;
use Botble\Support\Http\Requests\Request;
use Illuminate\Validation\Rule;

class CategoryRequest extends Request
{
    public function rules(): array
    {
        return [
            'title' => ['string','required'],
            'description' => 'required',
        
            'is_feature' => Rule::in(BaseStatusEnum::values()),
        ];
    }
  
}
