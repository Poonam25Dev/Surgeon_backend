<?php

namespace Botble\Doctors\Http\Controllers;

use Botble\Base\Http\Actions\DeleteResourceAction;
use Botble\Doctors\Http\Requests\DoctorsRequest;
use Botble\Doctors\Models\Doctors;
use Botble\Doctors\Models\DoctorCategory as Category;
use Botble\Base\Http\Controllers\BaseController;
use Botble\Doctors\Tables\DoctorsTable;
use Botble\Doctors\Forms\DoctorsForm;
use Botble\ACL\Models\User;
use Botble\ACL\Models\Role;
use Illuminate\Support\Facades\Hash;
use Botble\Media\Models\MediaFile;
use Illuminate\Support\Str;

class DoctorsController extends BaseController
{
    public function __construct()
    {
        $this
            ->breadcrumb()
            ->add(trans(trans('plugins/doctors::doctors.name')), route('doctors.index'));
    }

    public function index(DoctorsTable $table)
    {
        $this->pageTitle(trans('plugins/doctors::doctors.name'));

        return $table->renderTable();
    }

    public function create()
    {
        $this->pageTitle(trans('plugins/doctors::doctors.create'));

        return DoctorsForm::create()->renderForm();
    }

    public function store(DoctorsRequest $request)
    {
        if ($request->has('category_select_id')) {
            $categoryTitle = Category::find($request->input('category_select_id'))->title ?? null;
            $request->merge(['specialty_title' => $categoryTitle]);
        }

        $form = DoctorsForm::create()->setRequest($request);

        $form->save();
        
        $doctor = $form->getModel();
        
        // Check if email already exists
        if (User::where('email', $request->input('email'))->exists()) {
            return $response->setError()->setMessage('Email already exists. Please use a different email.');
        }
    
        // Get media ID
        $media = MediaFile::where('url', $doctor->doctor_photo)->first();
        $mediaId = $media ? $media->id : null;
    
        // Create unique username
        // $username = Str::slug($doctor->name) . '-' . uniqid();
        $username = Str::slug($doctor->name);
    
        // Create user
        $user = User::create([
            'first_name' => $doctor->name,
            'username'   => $username,
            'email'      => $request->input('email'),
            'password'   => Hash::make('password123'),
            'avatar_id'  => $mediaId,
        ]);
    
        // Assign role
        $role = Role::where('name', 'Doctor')->first();
        if ($role) {
            $user->roles()->attach($role->id);
        }
        
        // Step 4: Update doctor record with user_id
        $doctor->user_id = $user->id;
        $doctor->save();

        return $this
            ->httpResponse()
            ->setPreviousUrl(route('doctors.index'))
            ->setNextUrl(route('doctors.edit', $form->getModel()->getKey()))
            ->setMessage(trans('core/base::notices.create_success_message'));
    }

    public function edit(Doctors $doctors)
    {
        $this->pageTitle(trans('core/base::forms.edit_item', ['name' => $doctors->name]));

        return DoctorsForm::createFromModel($doctors)->renderForm();
    }

    public function update(Doctors $doctors, DoctorsRequest $request)
    {
         if ($request->has('category_select_id')) {
            $categoryTitle = Category::find($request->input('category_select_id'))->title ?? null;
            $request->merge(['specialty_title' => $categoryTitle]);
        }
        DoctorsForm::createFromModel($doctors)
            ->setRequest($request)
            ->save();
            
            // If doctor has linked user
            if ($doctors->user_id) {
                $user = User::find($doctors->user_id);
        
                if ($user) {
                    // Check if email is unique (excluding current user)
                    $newEmail = $request->input('email');
                    if (User::where('email', $newEmail)->where('id', '!=', $user->id)->exists()) {
                        return $this->httpResponse()->setError()->setMessage('Email already exists. Please use a different email.');
                    }
        
                    // Get avatar ID from doctor photo
                    $media = MediaFile::where('url', $doctors->doctor_photo)->first();
                    $mediaId = $media ? $media->id : null;
        
                    // Update user info
                    $user->update([
                        'first_name' => $doctors->name,
                        'email' => $newEmail,
                        'avatar_id' => $mediaId,
                    ]);
                }
            }

        return $this
            ->httpResponse()
            ->setPreviousUrl(route('doctors.index'))
            ->setMessage(trans('core/base::notices.update_success_message'));
    }

    public function destroy(Doctors $doctors)
    {
        return DeleteResourceAction::make($doctors);
    }
}
