<?php

namespace Botble\Doctors\Http\Controllers;

use Botble\Base\Http\Actions\DeleteResourceAction;
use Botble\Doctors\Tables\DoctorCategoryTable;
use Botble\Doctors\Http\Requests\CategoryRequest;
use Botble\Doctors\Models\DoctorCategory as Category;
use Botble\Base\Http\Controllers\BaseController;
use Botble\Doctors\Forms\CategoryForm;
use Botble\ACL\Models\User;
use Botble\ACL\Models\Role;
use Illuminate\Support\Facades\Hash;
use Botble\Media\Models\MediaFile;
use Illuminate\Support\Str;

class CategoryController extends BaseController
{
    public function __construct()
    {
        $this
            ->breadcrumb()
            ->add(trans(trans('plugins/doctors::category.name')), route('doctors.category.index'));
    }

    public function index(DoctorCategoryTable $table)
    {
        $this->pageTitle(trans('plugins/doctors::category.name'));

        return $table->renderTable();
    }

    public function create()
    {
        $this->pageTitle(trans('plugins/doctors::category.create'));

        return CategoryForm::create()->renderForm();
    }

    public function store(CategoryRequest $request)
    {
        $form = CategoryForm::create()->setRequest($request);

        $form->save();
        
        $doc_category = $form->getModel();

        $form->save();

        $doc_category->save();

        return $this
            ->httpResponse()
            ->setPreviousUrl(route('doctors.category.index'))
            ->setNextUrl(route('doctors.category.edit', $form->getModel()->getKey()))
            ->setMessage(trans('core/base::notices.create_success_message'));
    }

    public function edit(Category $category)
    {
        $this->pageTitle(trans('core/base::forms.edit_item', ['name' => $category->name]));

        return CategoryForm::createFromModel($category)->renderForm();
    }

    public function update(Category $category, CategoryRequest $request)
    {
         CategoryForm::createFromModel($category)
            ->setRequest($request)
            ->save();

        return $this
            ->httpResponse()
            ->setPreviousUrl(route('doctors.category.index'))
            ->setMessage(trans('core/base::notices.update_success_message'));
    }

    public function destroy(Category $category)
    {
        return DeleteResourceAction::make($category);
    }
}
