<?php

namespace Botble\CmsPluginsPlans\Http\Controllers\API;
use Botble\Base\Http\Controllers\BaseController;
use Botble\CmsPluginsPlans\Models\CmsPluginsPlans;
use Botble\Doctors\Models\DoctorCategory as Category;
use Botble\Doctors\Models\Doctors as Doctor;
use Botble\CmsPluginsPlans\Http\Resources\PlanResource;
use Botble\CmsPluginsPlans\Models\CmsPluginsPlans as Plan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Stripe\Checkout\Session;
use Illuminate\Support\Str;
use App\Models\PaymentDetail;
use Stripe\Customer;
use Carbon\Carbon;
use Stripe\Stripe;

class CategoryController extends BaseController
{
    public function index(Request $request){
        $categories = Category::paginate(10);

        response()->json([ 

                        'success' => true,
                        'data' => [
                                    'items' => $categories->items(), // only the records
                                    'pagination' => [
                                        'current_page' => $categories->currentPage(),
                                        'last_page' => $categories->lastPage(),
                                        'per_page' => $categories->perPage(),
                                        'total' => $categories->total(),
                                    ]
                               ] 
                    ]);
    }
    public function getDoctors(Request $request){

        $doctors = Doctor::paginate(10);
        
        return response()->json([ 

                        'success' => true,
                        'data' => [
                                    'items' => $doctors->items(), // only the records
                                    'pagination' => [
                                        'current_page' => $doctors->currentPage(),
                                        'last_page' => $doctors->lastPage(),
                                        'per_page' => $doctors->perPage(),
                                        'total' => $doctors->total(),
                                    ]
                               ] 
                    ]);
        }

}
