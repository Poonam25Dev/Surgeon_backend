<?php

return [
    [
        'name' => 'Doctors',
        'flag' => 'doctors.index',
    ],
    [
        'name' => 'Create',
        'flag' => 'doctors.create',
        'parent_flag' => 'doctors.index',
    ],
    [
        'name' => 'Edit',
        'flag' => 'doctors.edit',
        'parent_flag' => 'doctors.index',
    ],
    [
        'name' => 'Delete',
        'flag' => 'doctors.destroy',
        'parent_flag' => 'doctors.index',
    ],
];
