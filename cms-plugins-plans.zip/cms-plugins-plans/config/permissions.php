<?php

return [
    [
        'name' => 'plans',
        'flag' => 'plans.index',
    ],
    [
        'name' => 'Create',
        'flag' => 'plans.create',
        'parent_flag' => 'plans.index',
    ],
    [
        'name' => 'Edit',
        'flag' => 'plans.edit',
        'parent_flag' => 'plans.index',
    ],
    [
        'name' => 'Delete',
        'flag' => 'plans.destroy',
        'parent_flag' => 'plans.index',
    ],
];
