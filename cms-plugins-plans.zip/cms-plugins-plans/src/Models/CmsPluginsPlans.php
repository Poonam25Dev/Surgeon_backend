<?php

namespace Botble\CmsPluginsPlans\Models;

use Botble\Base\Casts\SafeContent;
use Botble\Base\Enums\BaseStatusEnum;
use Botble\Base\Models\BaseModel;

class CmsPluginsPlans extends BaseModel
{
    protected $table = 'cms_plugins_plans';

   protected $fillable = [
        'name',
        'heading',
        'description',
        'price',
        'image',
        'status',
    ];


    protected $casts = [
        'status' => BaseStatusEnum::class,
        'name' => SafeContent::class,
    ];
}
