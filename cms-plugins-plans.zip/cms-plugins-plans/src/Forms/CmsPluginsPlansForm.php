<?php

namespace Botble\CmsPluginsPlans\Forms;

use Botble\Base\Forms\FieldOptions\NameFieldOption;
use Botble\Base\Forms\FieldOptions\StatusFieldOption;
use Botble\Base\Forms\Fields\SelectField;
use Botble\Base\Forms\Fields\TextField;
use Botble\Base\Forms\FormAbstract;
use Botble\CmsPluginsPlans\Http\Requests\CmsPluginsPlansRequest;
use Botble\CmsPluginsPlans\Models\CmsPluginsPlans;
use Botble\Base\Forms\Fields\EditorField;
use Botble\Base\Forms\FieldOptions\TextFieldOption;
use Botble\Base\Forms\FieldOptions\EditorFieldOption;

class CmsPluginsPlansForm extends FormAbstract
{
    public function setup(): void
    {
        $this
            ->model(CmsPluginsPlans::class)
            ->setValidatorClass(CmsPluginsPlansRequest::class)
            ->add('name', TextField::class, NameFieldOption::make()->required())
            ->add('heading', TextField::class, TextFieldOption::make())
            ->add('description',  EditorField::class, EditorFieldOption::make()
                    ->allowedShortcodes() // If you want to allow UI Block (shortcodes) button in that editor
                    ->maxLength(10000) // Default is 10000, you can change it if you wish
                    ->rows(4) // Default is 4, you can change it if you wish
            )
            ->add('price', TextField::class, [
                'label' => 'Price',
                'attr' => [
                    'placeholder' => 'Enter price',
                    'class' => 'form-control',
                ],
            ])
               ->add('image', 'mediaImage', [
                    'label' => 'Image',
                ])
            ->add('status', SelectField::class, StatusFieldOption::make())
            ->setBreakFieldPoint('status');
    }
}
