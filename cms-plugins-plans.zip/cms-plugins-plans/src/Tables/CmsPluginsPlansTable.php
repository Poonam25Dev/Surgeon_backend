<?php

namespace Botble\CmsPluginsPlans\Tables;

use Botble\CmsPluginsPlans\Models\CmsPluginsPlans;
use Botble\Table\Abstracts\TableAbstract;
use Botble\Table\Actions\DeleteAction;
use Botble\Table\Actions\EditAction;
use Botble\Table\BulkActions\DeleteBulkAction;
use Botble\Table\BulkChanges\CreatedAtBulkChange;
use Botble\Table\Columns\ImageColumn;
use Botble\Table\BulkChanges\NameBulkChange;
use Botble\Table\BulkChanges\StatusBulkChange;
use Botble\Table\Columns\CreatedAtColumn;
use Botble\Table\Columns\IdColumn;
use Botble\Table\Columns\Column;
use Botble\Table\Columns\NameColumn;
use Botble\Table\Columns\StatusColumn;
use Botble\Table\HeaderActions\CreateHeaderAction;
use Illuminate\Database\Eloquent\Builder;

class CmsPluginsPlansTable extends TableAbstract
{
    public function setup(): void
    {
        $this
            ->model(CmsPluginsPlans::class)
            ->addHeaderAction(CreateHeaderAction::make()->route('plans.create'))
            ->addActions([
                EditAction::make()->route('plans.edit'),
                DeleteAction::make()->route('plans.destroy'),
            ])
            ->addColumns([
                IdColumn::make(),
                NameColumn::make()->route('plans.edit'),
                Column::make('heading')->title('Heading'),
                Column::make('description')->title('Description'),
                ImageColumn::make('image')
                    ->title('Image')
                    ->width(70),
                Column::make('price')->title('Price')->alignLeft(),
                CreatedAtColumn::make(),
                StatusColumn::make(),
            ])
            ->addBulkActions([
                DeleteBulkAction::make()->permission('plans.destroy'),
            ])
            ->addBulkChanges([
                NameBulkChange::make(),
                StatusBulkChange::make(),
                CreatedAtBulkChange::make(),
            ])
            ->queryUsing(function (Builder $query) {
                $query->select([
                    'id',
                    'name',
                    'image',
                    'heading',
                    'description',
                    'price',
                    'created_at',
                    'status',
                ]);
            });
    }
}
