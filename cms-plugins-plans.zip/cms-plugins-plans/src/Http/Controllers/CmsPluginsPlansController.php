<?php

namespace Botble\CmsPluginsPlans\Http\Controllers;

use Botble\Base\Http\Actions\DeleteResourceAction;
use Botble\CmsPluginsPlans\Http\Requests\CmsPluginsPlansRequest;
use Botble\CmsPluginsPlans\Models\CmsPluginsPlans;
use Botble\Base\Http\Controllers\BaseController;
use Botble\CmsPluginsPlans\Tables\CmsPluginsPlansTable;
use Botble\CmsPluginsPlans\Forms\CmsPluginsPlansForm;

class CmsPluginsPlansController extends BaseController
{
    public function __construct()
    {
        $this
            ->breadcrumb()
            ->add(trans(trans('plugins/cms plugins plans::plans.name')), route('plans.index'));
    }

    public function index(CmsPluginsPlansTable $table)
    {
        $this->pageTitle(trans('plugins/cms plugins plans::plans.name'));

        return $table->renderTable();
    }

    public function create()
    {
        $this->pageTitle(trans('plugins/cms plugins plans::plans.create'));

        return CmsPluginsPlansForm::create()->renderForm();
    }

    public function store(CmsPluginsPlansRequest $request)
    {
        $form = CmsPluginsPlansForm::create()->setRequest($request);

        $form->save();

        return $this
            ->httpResponse()
            ->setPreviousUrl(route('plans.index'))
            ->setNextUrl(route('plans.edit', $form->getModel()->getKey()))
            ->setMessage(trans('core/base::notices.create_success_message'));
    }

    public function edit(CmsPluginsPlans $cmsPluginsPlans)
    {
        $this->pageTitle(trans('core/base::forms.edit_item', ['name' => $cmsPluginsPlans->name]));

        return CmsPluginsPlansForm::createFromModel($cmsPluginsPlans)->renderForm();
    }

    public function update(CmsPluginsPlans $cmsPluginsPlans, CmsPluginsPlansRequest $request)
    {
        CmsPluginsPlansForm::createFromModel($cmsPluginsPlans)
            ->setRequest($request)
            ->save();

        return $this
            ->httpResponse()
            ->setPreviousUrl(route('plans.index'))
            ->setMessage(trans('core/base::notices.update_success_message'));
    }

    public function destroy(CmsPluginsPlans $cmsPluginsPlans)
    {
        return DeleteResourceAction::make($cmsPluginsPlans);
    }

}
