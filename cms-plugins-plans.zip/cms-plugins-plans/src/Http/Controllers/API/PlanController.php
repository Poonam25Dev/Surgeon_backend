<?php

namespace Botble\CmsPluginsPlans\Http\Controllers\API;
use Botble\Base\Http\Controllers\BaseController;
use Botble\CmsPluginsPlans\Models\CmsPluginsPlans;
use Botble\CmsPluginsPlans\Http\Resources\PlanResource;
use Botble\Slug\Facades\SlugHelper;
use Illuminate\Http\Request;

class PlanController extends BaseController
{
    /**
     * List posts
     *
     * @group Blog
     */
    public function index(Request $request)
    {
        $plans = CmsPluginsPlans::select([
            'id',
            'name',
            'heading',
            'description',
            'price',
            'image',
            'status',
            'created_at',
        ])
            ->where('status', 'published') // or '1', depending on your status column
            ->orderByDesc('created_at')
            ->paginate($request->input('per_page', 10));

            return response()->json([
                'success' => true,
                'data' => $plans,
            ]);
    }


}
