<?php

namespace Botble\CmsPluginsPlans\Http\Controllers\API;
use Botble\Base\Http\Controllers\BaseController;
use Botble\CmsPluginsPlans\Models\CmsPluginsPlans;
use Botble\CmsPluginsPlans\Http\Resources\PlanResource;
use Botble\CmsPluginsPlans\Models\CmsPluginsPlans as Plan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Stripe\Checkout\Session;
use Illuminate\Support\Str;
use App\Models\PaymentDetail;
use Stripe\Customer;
use Carbon\Carbon;
use Stripe\Stripe;

class PaymentController extends BaseController
{
    
    public function createCustomer(Request $request){
        
        
        $user = Auth::user();

        $stripe = new \Stripe\StripeClient([
            'api_key' => env('STRIPE_SECRET'),
            'stripe_version' => '2025-04-30.basil',
            ]);

        $orderId = 'ORD-' . Carbon::now()->format('Ymd') . '-' . strtoupper(Str::random(6));

        $customer = $stripe->customers->create([
            'name' => $user->name,
            'email' => $user->email,
            'metadata' => [
                'order_id' => $orderId,
                'doctor_id' => $user->id,
                'plan_id'=> $request->plan_id]
            ]);
            
         return response()->json([
                'success' => true,
                'data' => $customer,
            ]);
    }


    public function createCheckoutSession(Request $request){
        $plan_id = $request->plan_id;
        $plan = Plan::find($plan_id);
        $price_id = $request->input('price_id') ?? 'price_1RYjH8RlHEF0FIhH2zz5fogC';
        $stripe = new \Stripe\StripeClient([
            'api_key' => env('STRIPE_SECRET'),
            'stripe_version' => '2025-04-30.basil',
            ]);

        $session = $stripe->checkout->sessions->create([
        'success_url' => env('FRONTEND_URL') . '/success',
        'cancel_url' => env('FRONTEND_URL') . '/cancel',

        // 'line_items' => [
        //     // [
        //     // 'price' => $price_id,
        //     // // 'price' => $plan->price,
        //     // // 'quantity' => 1,
            
        //     // ],
        //     [
        //         'price_data' => [
        //             'currency' => 'USD',
        //             'product_data' => [
        //                     'name' => $plan->name,
        //                     'description' => $plan->description,
        //                     'heading' => $plan->heading,
        //                     'unit_amount' => $plan->price * 100,
        //                 ],
        //             'quantity' => 1,     
        //         ],
        //     ],

        // ],
        'line_items' => [[
        'price_data' => [
            'currency' => 'USD',
            'unit_amount' => $plan->price * 100,
            'product_data' => [
                'name' => $plan->name,
                'description' => $plan->description,
            ],
            'recurring' => [ // Only for subscriptions
                'interval' => 'month',
            ],
        ],
        'quantity' => 1, // ✅ Should be outside price_data
]],
        'mode' => 'subscription',
        ]);

          return response()->json([
                'success' => true,  
                'data' => $session,
            ]);
    }

    public function session_detail($session_id){
        try {
            $stripe = new \Stripe\StripeClient(env('STRIPE_SECRET'));
             $user = Auth::user();
            $session = $stripe->checkout->sessions->retrieve(
                $session_id,
                ['expand' => ['payment_intent', 'customer', 'subscription']]
            );

             if ($session->payment_status === 'paid') {
              
                PaymentDetail::create([
                'stripe_price_id'     => $session['subscription']['items']['data'][0]['price']['id'],
                'amount'              => $session->amount_total / 100,
                // // 'status'              => $session->payment_status, // e.g., 'paid'
                // 'doctor_id'           => $session->customer->metadata['doctor_id'] ?? null,
                // 'plan_id'             => $session->customer->metadata['plan_id'] ?? null,
            // =========
                'amount'              => $session->amount_total / 100,
                'status'              => 'success', // e.g., 'paid'
                'doctor_id'           => 6,
                'plan_id'             => 1,
            // ==========
                'stripe_customer_id'  => $session->customer->id,
                'total_duration'      => 3,
                // 'status'              => $session->status ?? 'success'
             
            ]);
            }

            return response()->json([
                'success' => true,
                'status' => $session->payment_status,
                'customer' => $session->customer,
                'meta'     => $session->customer->metadata,
                'subscription' => $session->subscription,
                'amount_total' => $session->amount_total / 100,
                'currency' => $session->currency,
                'payment_intent' => $session->payment_intent,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Session not found or invalid: ' . $e->getMessage(),
            ], 404);
        }

    }



}
