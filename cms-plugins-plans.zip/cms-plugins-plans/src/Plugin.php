<?php

namespace Botble\CmsPluginsPlans;

use Illuminate\Support\Facades\Schema;
use Botble\PluginManagement\Abstracts\PluginOperationAbstract;

class Plugin extends PluginOperationAbstract
{
    public static function remove(): void
    {
        Schema::dropIfExists('Cms Plugins Plans');
        Schema::dropIfExists('Cms Plugins Plans_translations');
    }
}
