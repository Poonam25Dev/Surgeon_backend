<?php

namespace Botble\CmsPluginsPlans\Providers;
use Botble\Api\Facades\ApiHelper;
use Botble\Base\Supports\ServiceProvider;
use Botble\Base\Traits\LoadAndPublishDataTrait;
use Botble\Base\Facades\DashboardMenu;
use Botble\CmsPluginsPlans\Models\CmsPluginsPlans;

class CmsPluginsPlansServiceProvider extends ServiceProvider
{
    use LoadAndPublishDataTrait;

    public function boot(): void
    {
        $this
            ->setNamespace('plugins/cms-plugins-plans')
            ->loadHelpers()
            ->loadAndPublishConfigurations(['permissions'])
            ->loadAndPublishTranslations()
            ->loadRoutes()
            ->loadAndPublishViews()
            ->loadMigrations();
            
            if (defined('LANGUAGE_ADVANCED_MODULE_SCREEN_NAME')) {
                \Botble\LanguageAdvanced\Supports\LanguageAdvancedManager::registerModule(CmsPluginsPlans::class, [
                    'name',
                ]);
            }
            
            if (class_exists('ApiHelper') && ApiHelper::enabled()) {
                $this->loadRoutes(['api']);
            }
            DashboardMenu::default()->beforeRetrieving(function () {
                DashboardMenu::registerItem([
                    'id' => 'cms-plugins-cms plugins plans',
                    'priority' => 5,
                    'parent_id' => null,
                    'name' => 'plans',
                    'icon' => 'ti ti-box',
                    'url' => route('plans.index'),
                    'permissions' => ['plans.index'],
                ]);
            });

    }
}
