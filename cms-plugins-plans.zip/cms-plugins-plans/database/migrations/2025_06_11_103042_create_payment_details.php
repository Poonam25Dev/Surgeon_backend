<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('payment_details', function (Blueprint $table) {
            $table->id();
            $table->string('stripe_price_id')->nullable();
            $table->string('stripe_customer_id')->nullable();
            $table->foreignId('plan_id')->constrained('cms_plugins_plans')->onDelete('cascade');
            $table->foreignId('doctor_id')->constrained('doctors')->onDelete('cascade');
            $table->decimal('amount', 8, 2);
            $table->integer('total_duration')->default(0);
            $table->enum('status', ['success', 'fail', 'abort']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('payment_details');
    }
};
