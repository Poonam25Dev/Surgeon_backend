<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class () extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('cms_plugins_plans')) {
            Schema::create('cms_plugins_plans', function (Blueprint $table) {
                $table->id();
                $table->string('name', 255);
                $table->string('heading', 255)->nullable();
                $table->string('image')->nullable();
                $table->longText('description')->nullable();
                $table->decimal('price', 8, 2);
                $table->string('status', 60)->default('published');
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('cms_plugins_plans_translations')) {
            Schema::create('cms_plugins_plans_translations', function (Blueprint $table) {
                $table->string('lang_code');
                $table->foreignId('cms_plugins_plans_id');
                $table->string('name', 255)->nullable();

                $table->primary(['lang_code', 'cms_plugins_plans_id'], 'cms_plugins_plans_translations_primary');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('cms_plugins_plans');
        Schema::dropIfExists('cms_plugins_plans_translations');
    }
};
