<?php

return [
    'name' => 'Cms plugins plans',
    'create' => 'New cms plugins plans',
];
