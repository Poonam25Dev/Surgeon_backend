<?php

use Illuminate\Support\Facades\Route;

Route::group([
    'middleware' => 'api',
    'prefix' => 'api/v1',
    'namespace' => 'Botble\CmsPluginsPlans\Http\Controllers\API'

], function () {
    Route::get('/plan-list', 'PlanController@index');
    Route::post('create-customer', 'PaymentController@createCustomer');
    Route::post('checkout/session', 'PaymentController@createCheckoutSession');
    Route::get('session/{session_id}', 'PaymentController@session_detail');

});

