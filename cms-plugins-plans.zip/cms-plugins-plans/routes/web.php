<?php

use Botble\Base\Facades\AdminHelper;
use Botble\CmsPluginsPlans\Http\Controllers\CmsPluginsPlansController;
use Illuminate\Support\Facades\Route;

AdminHelper::registerRoutes(function () {
    Route::group(['prefix' => 'plans', 'as' => 'plans.'], function () {
        Route::resource('', CmsPluginsPlansController::class)->parameters(['' => 'cms-plugins-plans']);
    });
});
